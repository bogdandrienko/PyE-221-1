# django-simple-mvt-for-heroku-webapp-task-list
Simple example Django MVT(Model-View-Template) for Heroku platform - Task list webapp

### Here is a demonstration of how the application looks and its working.

#### The App has 4 features:
- **Pen Color**
- **Pen Thickness**
- **Undo**
- **Clear**

![Draw](new.gif)